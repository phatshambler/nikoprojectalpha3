<?php
					
		
					header("HTTP/1.1 307 Temporary Redirect");
					header("Location: /nikoprojectalpha3/Web JMD - B63/index.php"); exit;
					
					